const assaultTypes = [
  {
    botType: "assault",
    difficulty: "easy",
  },
  {
    botType: "cursedassault",
    difficulty: "easy",
  },
  {
    botType: "assault",
    difficulty: "normal",
  },
  {
    botType: "cursedassault",
    difficulty: "normal",
  },
  {
    botType: "assault",
    difficulty: "hard",
  },
  {
    botType: "cursedassault",
    difficulty: "hard",
  },
  {
    botType: "assault",
    difficulty: "impossible",
  },
  {
    botType: "cursedassault",
    difficulty: "impossible",
  },
];
