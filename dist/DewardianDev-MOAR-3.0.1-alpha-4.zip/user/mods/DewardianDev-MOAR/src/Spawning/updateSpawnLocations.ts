import { ILocation } from "@spt/models/eft/common/ILocation";
import { configLocations } from "./constants";
import _config from "../../config/config.json";
import { getRandomInArray, shuffle } from "./utils";
import { ISpawnPointParam } from "@spt/models/eft/common/ILocationBase";
import { globalValues } from "../GlobalValues";
import getSortedSpawnPointList from "./spawnZoneUtils";

export default function updateSpawnLocations(
  locationList: ILocation[],
  config: typeof _config
) {
  for (let index = 0; index < locationList.length; index++) {
    const map = configLocations[index];
    const playerSpawns: ISpawnPointParam[] = [];
    const mapSpawns = globalValues.indexedMapSpawns[index];

    mapSpawns.forEach((point) => {
      if (point?.["type"] === "coop") {
        playerSpawns.push(point);
        return false;
      }

      return true;
    });



    const playerSpawn: ISpawnPointParam = getRandomInArray(playerSpawns);

    const { x, y, z } = playerSpawn.Position;

    const sortedSpawnPointList = getSortedSpawnPointList(
      mapSpawns,
      x,
      y,
      z
    );

    const possibleSpawnList: ISpawnPointParam[] = []

    sortedSpawnPointList.forEach((point) => {
      if (possibleSpawnList.length < 6 && (point?.["type"] === "coop" || point?.["type"] === "pmc" || point?.["type"] === "scav")) {
        possibleSpawnList.push({
          ...point,
          Categories: ["Player"],
          BotZoneName: point?.BotZoneName ? point.BotZoneName : "",
          CorePointId: 0,
          Sides: ["Pmc"],
          Infiltration: playerSpawn.Infiltration
        });
      }
    })


    const possibleSpawnSet = new Set([...playerSpawns, ...possibleSpawnList].map(({ Id }) => Id))

    const filtered = sortedSpawnPointList.filter((point) => !possibleSpawnSet.has(point.Id))

    locationList[index].base.SpawnPointParams = filtered;

    locationList[index].base.SpawnPointParams.push(...possibleSpawnList);
    console.log(locationList[index].base.SpawnPointParams.filter(point => point?.Categories[0] === "Player").map(point => point.Position))

    const listToAddToOpenZones = [...new Set(locationList[index].base.SpawnPointParams.map(({ BotZoneName }) => BotZoneName).filter((zone) => !!zone))]

    locationList[index].base.OpenZones = listToAddToOpenZones.join(",");


  }
}
