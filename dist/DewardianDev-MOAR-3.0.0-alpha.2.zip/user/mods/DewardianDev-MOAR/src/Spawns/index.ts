// context/index.js
export { default as PlayerSpawns } from "./playerSpawns.json";
export { default as BotSpawns } from "./botSpawns.json";
export { default as SniperSpawns } from "./sniperSpawns.json";
